import java.util.function.Predicate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Iterator;
class Main {
  public static List<Observacion> observaciones=new ArrayList<>();
  public static List<Data> data=new ArrayList<>();
  public static void main(String[] args) {
    Archivo a=new Archivo();
    a.leerTxt("listas.txt");
    List<String> datos=a.getData();

    


    for (String d:datos){
      String m=d.split(",")[0];
      String v=d.split(",")[1];
      data.add(new Data(m.replace("\"", ""),v.replace("\"", "")));
    }

 
    
      Iterator <Data> it=data.iterator();

      while (it.hasNext()){

        Data iDn=it.next();
      data.stream().filter(id -> id.getNombre().equals(iDn.getNombre())).map(id -> id.getDato()).forEach(System.out::println);
      }
    }
    
    
}
