/*import java.util.function.Predicate;

class Fil{

public static Predicate<String> filtroID(String id){

  return (String i) ->{
    return g.split(",")[0].equals(id);
  };

}





}*/