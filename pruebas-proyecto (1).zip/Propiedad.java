import java.util.ArrayList;
import java.util.List;
class Propiedad{
private String nombre;
private List<Observacion> observaciones;


public Propiedad(String n){
nombre=n;
observaciones= new ArrayList<>();
}
String getNombre(){
return nombre;
}

public void realizarObs(Observacion o){
  observaciones.add(o);

}
List<Observacion> getArray(){

return observaciones;
}

public void imprimirValor(){

    for (Observacion c: observaciones){
        System.out.println(c.getValue());
         }

  }
}