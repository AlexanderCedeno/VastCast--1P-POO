class User{
private String id_User;


public User(String id){
  id_User=id;
}


}