import java.util.ArrayList;
import java.util.List;

abstract class PopUp{
protected List<Propiedad> propiedades;
protected String label;
protected boolean state;

public PopUp(String l){
  label=l;
  state=true;
  propiedades= new ArrayList<>();
}

public abstract void setPopUp();

public String getLabel(){
  return label;
}
public void añadirProp(Propiedad p){
  propiedades.add(p);
}

public List<Propiedad> getListProp(){
  return propiedades;
}

}