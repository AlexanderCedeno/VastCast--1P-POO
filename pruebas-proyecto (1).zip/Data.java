

class Data{
private String nombre;
private String dato;

public Data(String n, String d){
  nombre=n;
  dato=d;
}

public String getNombre(){
  return nombre;
}

public String getDato(){
  return dato;
}

}