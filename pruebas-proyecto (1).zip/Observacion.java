class Observacion{

private String value;

Observacion (String v){
value=v;}

String getValue(){
return value;
}
}